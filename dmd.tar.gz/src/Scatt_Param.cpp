#include "Scatt_Param.h"

coulombParam clp;
elecimpParam eip;
elecelecParam eep;