#pragma once
#include <scalar.h>

const complex c0(0, 0);
const complex c1(1, 0);
const complex cm1(-1, 0);
const complex ci(0, 1);
const complex cmi(0, -1);